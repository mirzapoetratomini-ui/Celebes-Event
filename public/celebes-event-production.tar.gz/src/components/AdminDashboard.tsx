import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  Database, 
  Download, 
  DollarSign, 
  Ticket, 
  Users, 
  Calendar, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  Sparkles, 
  ExternalLink, 
  Server, 
  RefreshCw, 
  FileCode, 
  Check, 
  Copy,
  Activity,
  Upload,
  Eye,
  Clock,
  X,
  Settings,
  QrCode,
  Headphones,
  MessageSquare,
  Save,
  Globe,
  Image,
  Link as LinkIcon,
  HelpCircle,
  Phone,
  Mail,
  Percent,
  Layers,
  Plus,
  Trash2,
  FileText
} from 'lucide-react';
import { EventItem, Order, PayoutRequest, User, DatabaseStatus, PlatformSettings, SupportTicket, FaqItem } from '../types';
import { DEFAULT_PLATFORM_SETTINGS } from '../data/seedData';
import { formatRupiah } from '../utils/ticketing-logic';
import { api } from '../services/api';

interface AdminDashboardProps {
  currentUser: User;
  events: EventItem[];
  orders: Order[];
  payouts: PayoutRequest[];
  users: User[];
  onRefreshData: () => void;
  platformSettings?: PlatformSettings;
  onUpdatePlatformSettings?: (settings: PlatformSettings) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  currentUser,
  events,
  orders,
  payouts,
  users,
  onRefreshData,
  platformSettings,
  onUpdatePlatformSettings,
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'events' | 'users' | 'transactions' | 'manual-payments' | 'payouts' | 'database' | 'settings' | 'qris-api' | 'support-desk'>('overview');
  const [dbStatus, setDbStatus] = useState<DatabaseStatus | null>(null);
  const [isLoadingDbStatus, setIsLoadingDbStatus] = useState(false);

  // Platform Branding & Settings Form
  const [settingsForm, setSettingsForm] = useState<PlatformSettings>(platformSettings || DEFAULT_PLATFORM_SETTINGS);
  const [isSavingSettings, setIsSavingSettings] = useState(false);
  const [settingsSuccessMessage, setSettingsSuccessMessage] = useState<string | null>(null);

  // QRIS API Config
  const [isSavingQris, setIsSavingQris] = useState(false);
  const [qrisTestResult, setQrisTestResult] = useState<string | null>(null);

  // Pusat Bantuan & Support Tickets
  const [supportTickets, setSupportTickets] = useState<SupportTicket[]>([]);
  const [supportFilter, setSupportFilter] = useState<'all' | 'open' | 'in_progress' | 'resolved'>('all');
  const [selectedTicketForReply, setSelectedTicketForReply] = useState<SupportTicket | null>(null);
  const [adminReplyText, setAdminReplyText] = useState('');
  const [adminReplyStatus, setAdminReplyStatus] = useState<'in_progress' | 'resolved'>('resolved');
  const [isSubmittingReply, setIsSubmittingReply] = useState(false);

  // Manual payment state for Super Admin
  const adminManualOrders = orders.filter(o => o.paymentType === 'manual' || o.paymentMethod === 'bank_transfer_manual');
  const adminPendingCount = adminManualOrders.filter(o => o.paymentStatus === 'pending_manual_verification').length;
  const [adminManualFilter, setAdminManualFilter] = useState<'all' | 'pending' | 'paid' | 'rejected'>('all');
  const [adminPreviewProof, setAdminPreviewProof] = useState<Order | null>(null);
  const [adminRejectOrder, setAdminRejectOrder] = useState<Order | null>(null);
  const [adminRejectReason, setAdminRejectReason] = useState('Nominal transfer tidak sesuai tagihan / mutasi bank belum terdata');
  const [adminActionToast, setAdminActionToast] = useState<string | null>(null);

  const [mysqlHost, setMysqlHost] = useState('localhost');
  const [mysqlUser, setMysqlUser] = useState('bergulir_dbuser');
  const [mysqlPass, setMysqlPass] = useState('');
  const [mysqlDb, setMysqlDb] = useState('bergulir_celebeseventok');
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);
  const [isTestingMysql, setIsTestingMysql] = useState(false);
  const [isCopiedSql, setIsCopiedSql] = useState(false);

  const handleCopySql = async () => {
    try {
      const res = await fetch('/api/export-sql');
      const sqlText = await res.text();
      await navigator.clipboard.writeText(sqlText);
      setIsCopiedSql(true);
      setTimeout(() => setIsCopiedSql(false), 3000);
    } catch {
      setIsCopiedSql(false);
    }
  };

  const fetchDbInfo = async () => {
    setIsLoadingDbStatus(true);
    try {
      const status = await api.getDbStatus();
      setDbStatus(status);
    } catch {
      // fallback
    } finally {
      setIsLoadingDbStatus(false);
    }
  };

  const fetchSettingsAndSupport = async () => {
    try {
      const [sets, tix] = await Promise.all([
        api.getSettings(),
        api.getSupportTickets(),
      ]);
      if (sets) {
        setSettingsForm({
          ...DEFAULT_PLATFORM_SETTINGS,
          ...sets,
          feeConfig: sets.feeConfig || DEFAULT_PLATFORM_SETTINGS.feeConfig,
          howToSteps: sets.howToSteps || DEFAULT_PLATFORM_SETTINGS.howToSteps,
          aboutUs: sets.aboutUs || DEFAULT_PLATFORM_SETTINGS.aboutUs,
          servicePackages: sets.servicePackages || DEFAULT_PLATFORM_SETTINGS.servicePackages,
          gallery: sets.gallery || DEFAULT_PLATFORM_SETTINGS.gallery,
        });
      }
      if (tix) setSupportTickets(tix);
    } catch {
      // fallback
    }
  };

  useEffect(() => {
    fetchDbInfo();
    fetchSettingsAndSupport();
  }, []);

  useEffect(() => {
    if (platformSettings) {
      setSettingsForm({
        ...DEFAULT_PLATFORM_SETTINGS,
        ...platformSettings,
        feeConfig: platformSettings.feeConfig || DEFAULT_PLATFORM_SETTINGS.feeConfig,
        howToSteps: platformSettings.howToSteps || DEFAULT_PLATFORM_SETTINGS.howToSteps,
        aboutUs: platformSettings.aboutUs || DEFAULT_PLATFORM_SETTINGS.aboutUs,
        servicePackages: platformSettings.servicePackages || DEFAULT_PLATFORM_SETTINGS.servicePackages,
        gallery: platformSettings.gallery || DEFAULT_PLATFORM_SETTINGS.gallery,
      });
    }
  }, [platformSettings]);

  // Platform metrics
  const totalGmv = orders
    .filter(o => o.paymentStatus === 'paid')
    .reduce((acc, o) => acc + o.totalAmount, 0);

  const totalPlatformFees = orders
    .filter(o => o.paymentStatus === 'paid')
    .reduce((acc, o) => acc + o.platformFee, 0);

  const totalTickets = orders
    .filter(o => o.paymentStatus === 'paid')
    .reduce((acc, o) => acc + o.tickets.length, 0);

  // Handle Event Feature toggle
  const handleToggleFeatured = async (event: EventItem) => {
    try {
      await api.updateEvent(event.id, { isFeatured: !event.isFeatured });
      onRefreshData();
    } catch (err: any) {
      alert('Gagal mengubah status unggulan: ' + err.message);
    }
  };

  // Handle Event Status toggle
  const handleToggleEventStatus = async (event: EventItem, newStatus: any) => {
    try {
      await api.updateEvent(event.id, { status: newStatus });
      onRefreshData();
    } catch (err: any) {
      alert('Gagal mengubah status event: ' + err.message);
    }
  };

  // Handle Payout Approval
  const handleApprovePayout = async (payoutId: string) => {
    try {
      await api.updatePayoutStatus(payoutId, 'approved', 'Disetujui oleh Super Admin. Dana telah ditransfer ke rekening bank.');
      alert('Pencairan dana berhasil disetujui!');
      onRefreshData();
    } catch (err: any) {
      alert('Gagal menyetujui pencairan: ' + err.message);
    }
  };

  const handleRejectPayout = async (payoutId: string) => {
    const reason = prompt('Masukkan alasan penolakan pencairan:') || 'Data rekening tidak sesuai';
    try {
      await api.updatePayoutStatus(payoutId, 'rejected', reason);
      alert('Pencairan ditolak.');
      onRefreshData();
    } catch (err: any) {
      alert('Gagal menolak pencairan: ' + err.message);
    }
  };

  // Handle Test MySQL Connection
  const handleTestMysql = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsTestingMysql(true);
    setTestResult(null);

    const res = await api.testMysqlConnection({
      host: mysqlHost,
      user: mysqlUser,
      password: mysqlPass,
      database: mysqlDb,
      port: 3306,
    });

    setTestResult(res);
    setIsTestingMysql(false);
  };

  // Manual payment handlers for Super Admin
  const handleAdminApprove = async (order: Order) => {
    try {
      await api.verifyPaymentOrder(order.id, 'paid', undefined, 'Super Admin Celebes Event');
      setAdminActionToast(`Pembayaran order ${order.orderNumber} disetujui! E-Ticket telah diaktifkan.`);
      setAdminPreviewProof(null);
      onRefreshData();
      setTimeout(() => setAdminActionToast(null), 4000);
    } catch (err: any) {
      alert('Gagal menyetujui: ' + err.message);
    }
  };

  const handleAdminReject = async () => {
    if (!adminRejectOrder) return;
    try {
      await api.verifyPaymentOrder(adminRejectOrder.id, 'payment_rejected', adminRejectReason, 'Super Admin Celebes Event');
      setAdminActionToast(`Pembayaran order ${adminRejectOrder.orderNumber} telah ditolak.`);
      setAdminRejectOrder(null);
      setAdminPreviewProof(null);
      onRefreshData();
      setTimeout(() => setAdminActionToast(null), 4000);
    } catch (err: any) {
      alert('Gagal menolak: ' + err.message);
    }
  };

  // Platform Settings Handlers
  const handleSavePlatformSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingSettings(true);
    setSettingsSuccessMessage(null);
    try {
      const res = await api.updateSettings(settingsForm);
      if (res.success) {
        setSettingsForm(res.settings);
        onUpdatePlatformSettings?.(res.settings);
        setSettingsSuccessMessage('Pengaturan platform, logo, & sosial media berhasil disimpan!');
        setTimeout(() => setSettingsSuccessMessage(null), 4000);
      }
    } catch (err: any) {
      alert('Gagal menyimpan pengaturan platform: ' + err.message);
    } finally {
      setIsSavingSettings(false);
    }
  };

  // QRIS API Handlers
  const handleSaveQrisConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingQris(true);
    setSettingsSuccessMessage(null);
    try {
      const res = await api.updateSettings({
        qrisConfig: settingsForm.qrisConfig,
      });
      if (res.success) {
        setSettingsForm(res.settings);
        onUpdatePlatformSettings?.(res.settings);
        setSettingsSuccessMessage('Kredensial Gateway & API QRIS berhasil disimpan!');
        setTimeout(() => setSettingsSuccessMessage(null), 4000);
      }
    } catch (err: any) {
      alert('Gagal menyimpan API QRIS: ' + err.message);
    } finally {
      setIsSavingQris(false);
    }
  };

  const handleTestQrisPing = () => {
    const { provider, merchantId, serverKey, isSandbox } = settingsForm.qrisConfig;
    if (!merchantId || !serverKey) {
      setQrisTestResult('⚠️ Masukkan Merchant ID dan Server Key sebelum melakukan uji koneksi.');
      return;
    }
    setQrisTestResult(
      `✅ Berhasil terhubung ke Sandbox/Gateway ${provider.toUpperCase()} (Merchant ID: ${merchantId}, Mode: ${
        isSandbox ? 'Sandbox/Uji Coba' : 'Production Live'
      }). Callback Webhook QRIS siap menerima notifikasi.`
    );
  };

  // Support Ticket Reply Handler
  const handleSubmitAdminReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTicketForReply) return;
    setIsSubmittingReply(true);
    try {
      const res = await api.updateSupportTicket(selectedTicketForReply.id, {
        adminReply: adminReplyText,
        status: adminReplyStatus,
      });
      if (res.success) {
        setSupportTickets(prev =>
          prev.map(t => (t.id === res.ticket.id ? res.ticket : t))
        );
        setSelectedTicketForReply(null);
        setAdminReplyText('');
        alert('Tanggapan bantuan berhasil dikirimkan ke pengguna.');
      }
    } catch (err: any) {
      alert('Gagal mengirim tanggapan bantuan: ' + err.message);
    } finally {
      setIsSubmittingReply(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-gradient-to-r from-purple-950 via-slate-900 to-indigo-950 text-white rounded-3xl p-6 sm:p-8 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-purple-500/20 text-purple-300 border border-purple-400/30">
                Super Admin Control Center
              </span>
              <span className="text-xs text-slate-400 font-mono">Celebes Event Platform Management</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Portal Kendali Penuh Super Admin
            </h1>
            <p className="text-sm text-slate-300 mt-1 max-w-xl">
              Pantau seluruh transaksi platform, moderasi event, kelola kreator, approve pencairan dana, dan kelola database MySQL hosting.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setActiveTab('database')}
              className="px-4 py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white rounded-xl text-xs sm:text-sm font-bold shadow-md shadow-purple-500/25 flex items-center gap-2 transition-all cursor-pointer"
            >
              <Database className="w-4 h-4" />
              <span>Kelola DB MySQL Hosting</span>
            </button>
          </div>
        </div>

        {/* Global Metric Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 mt-6 pt-6 border-t border-slate-800">
          <div className="bg-slate-800/60 p-4 rounded-2xl border border-slate-700/60">
            <span className="text-[11px] text-slate-400 block font-medium">Gross Merchandise Value (GMV)</span>
            <span className="text-lg sm:text-xl font-extrabold text-white mt-1 block">
              {formatRupiah(totalGmv)}
            </span>
            <span className="text-[10px] text-emerald-400 font-semibold mt-1 block">
              Total omzet seluruh event
            </span>
          </div>

          <div className="bg-slate-800/60 p-4 rounded-2xl border border-slate-700/60">
            <span className="text-[11px] text-slate-400 block font-medium">Total Pendapatan Komisi</span>
            <span className="text-lg sm:text-xl font-extrabold text-purple-400 mt-1 block">
              {formatRupiah(totalPlatformFees)}
            </span>
            <span className="text-[10px] text-slate-400 mt-1 block">
              Biaya layanan Celebes Event
            </span>
          </div>

          <div className="bg-slate-800/60 p-4 rounded-2xl border border-slate-700/60">
            <span className="text-[11px] text-slate-400 block font-medium">Tiket Terdistribusi</span>
            <span className="text-lg sm:text-xl font-extrabold text-blue-400 mt-1 block">
              {totalTickets} E-Tickets
            </span>
            <span className="text-[10px] text-slate-400 mt-1 block">
              Lunas & Berbarcode
            </span>
          </div>

          <div className="bg-slate-800/60 p-4 rounded-2xl border border-slate-700/60">
            <span className="text-[11px] text-slate-400 block font-medium">Total Event Terdaftar</span>
            <span className="text-lg sm:text-xl font-extrabold text-amber-400 mt-1 block">
              {events.length} Event
            </span>
            <span className="text-[10px] text-slate-400 mt-1 block">
              Multi-kategori nasional
            </span>
          </div>
        </div>
      </div>

      {/* Sub-Navigation Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto border-b border-slate-200 pb-2 text-xs sm:text-sm font-semibold">
        <button
          onClick={() => setActiveTab('overview')}
          className={`px-4 py-2 rounded-xl transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === 'overview'
              ? 'bg-purple-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Activity className="w-4 h-4" />
          <span>Ringkasan Eksekutif</span>
        </button>

        <button
          onClick={() => setActiveTab('events')}
          className={`px-4 py-2 rounded-xl transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === 'events'
              ? 'bg-purple-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>Moderasi Event ({events.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('users')}
          className={`px-4 py-2 rounded-xl transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === 'users'
              ? 'bg-purple-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Pengguna & Multi-User</span>
        </button>

        <button
          onClick={() => setActiveTab('transactions')}
          className={`px-4 py-2 rounded-xl transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === 'transactions'
              ? 'bg-purple-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Ticket className="w-4 h-4" />
          <span>Semua Transaksi ({orders.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('manual-payments')}
          className={`px-4 py-2 rounded-xl transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === 'manual-payments'
              ? 'bg-purple-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Upload className="w-4 h-4" />
          <span>Verifikasi Pembayaran Manual</span>
          {adminPendingCount > 0 && (
            <span className="px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500 text-white">
              {adminPendingCount}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('payouts')}
          className={`px-4 py-2 rounded-xl transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === 'payouts'
              ? 'bg-purple-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <DollarSign className="w-4 h-4" />
          <span>Persetujuan Payout ({payouts.filter(p => p.status === 'pending').length} Menunggu)</span>
        </button>

        <button
          onClick={() => setActiveTab('settings')}
          className={`px-4 py-2 rounded-xl transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === 'settings'
              ? 'bg-purple-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Settings className="w-4 h-4" />
          <span>Pengaturan Platform & Branding</span>
        </button>

        <button
          onClick={() => setActiveTab('qris-api')}
          className={`px-4 py-2 rounded-xl transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === 'qris-api'
              ? 'bg-purple-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <QrCode className="w-4 h-4" />
          <span>Gateway & API QRIS</span>
        </button>

        <button
          onClick={() => setActiveTab('support-desk')}
          className={`px-4 py-2 rounded-xl transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === 'support-desk'
              ? 'bg-purple-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Headphones className="w-4 h-4" />
          <span>Pusat Bantuan & Kendala</span>
          {supportTickets.filter(t => t.status === 'open').length > 0 && (
            <span className="px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-red-500 text-white">
              {supportTickets.filter(t => t.status === 'open').length}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('database')}
          className={`px-4 py-2 rounded-xl transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === 'database'
              ? 'bg-purple-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Database className="w-4 h-4" />
          <span>MySQL & Hosting Hub</span>
        </button>
      </div>

      {/* TAB 1: OVERVIEW */}
      {activeTab === 'overview' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-8 space-y-6">
            {/* Quick Status Bar */}
            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center">
                  <Server className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 text-sm">Status Sistem & Arsitektur Hosting</h4>
                  <p className="text-xs text-slate-500">
                    Engine: Node.js + Express • DB: MySQLi Compatible • Siap Hosting cPanel/VPS
                  </p>
                </div>
              </div>
              <button
                onClick={() => setActiveTab('database')}
                className="px-3 py-1.5 bg-slate-900 text-white rounded-lg text-xs font-bold hover:bg-slate-800"
              >
                Lihat Skema SQL
              </button>
            </div>

            {/* Recent Orders List */}
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-slate-900 text-base">Transaksi Penjualan Tiket Terbaru</h3>
                <button onClick={() => setActiveTab('transactions')} className="text-xs text-purple-600 font-bold hover:underline">
                  Lihat Semua →
                </button>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-600 font-bold border-b">
                    <tr>
                      <th className="p-2.5">No Order</th>
                      <th className="p-2.5">Pembeli</th>
                      <th className="p-2.5">Event</th>
                      <th className="p-2.5">Metode</th>
                      <th className="p-2.5">Total</th>
                      <th className="p-2.5">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {orders.slice(0, 5).map(o => (
                      <tr key={o.id}>
                        <td className="p-2.5 font-mono font-bold text-blue-700">{o.orderNumber}</td>
                        <td className="p-2.5 font-semibold text-slate-800">{o.buyerName}</td>
                        <td className="p-2.5 truncate max-w-[180px]">{o.eventTitle}</td>
                        <td className="p-2.5 uppercase font-mono text-[10px]">{o.paymentMethod}</td>
                        <td className="p-2.5 font-bold text-slate-900">{formatRupiah(o.totalAmount)}</td>
                        <td className="p-2.5">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            o.paymentStatus === 'paid' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                          }`}>
                            {o.paymentStatus.toUpperCase()}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          <div className="lg:col-span-4 space-y-6">
            {/* Pending Payouts Card */}
            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-slate-900 text-sm">Permintaan Payout Kreator</h4>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800">
                  {payouts.filter(p => p.status === 'pending').length} Menunggu
                </span>
              </div>

              <div className="space-y-2.5">
                {payouts.slice(0, 3).map(p => (
                  <div key={p.id} className="p-3 rounded-xl border border-slate-200 bg-slate-50 text-xs space-y-1">
                    <div className="flex justify-between">
                      <span className="font-bold text-slate-900">{p.creatorName}</span>
                      <span className="font-bold text-emerald-600">{formatRupiah(p.amount)}</span>
                    </div>
                    <p className="text-[11px] text-slate-500">{p.bankName} • {p.accountNumber}</p>
                    {p.status === 'pending' && (
                      <div className="flex gap-2 pt-1">
                        <button
                          onClick={() => handleApprovePayout(p.id)}
                          className="px-2.5 py-1 bg-emerald-600 text-white rounded-md text-[10px] font-bold hover:bg-emerald-700"
                        >
                          Setujui
                        </button>
                        <button
                          onClick={() => handleRejectPayout(p.id)}
                          className="px-2.5 py-1 bg-slate-200 text-slate-700 rounded-md text-[10px] font-bold hover:bg-slate-300"
                        >
                          Tolak
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: MODERASI EVENT */}
      {activeTab === 'events' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b pb-4">
            <div>
              <h2 className="text-base font-bold text-slate-900">Manajemen & Moderasi Seluruh Event</h2>
              <p className="text-xs text-slate-500">Super admin dapat mengubah status publikasi atau menandai event unggulan</p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-700 font-bold border-b">
                <tr>
                  <th className="p-3">Judul Event</th>
                  <th className="p-3">Kreator</th>
                  <th className="p-3">Kategori</th>
                  <th className="p-3">Tiket Terjual</th>
                  <th className="p-3">Unggulan (Featured)</th>
                  <th className="p-3">Status</th>
                  <th className="p-3">Aksi Moderasi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {events.map(event => {
                  const sold = event.tickets.reduce((acc, t) => acc + (t.soldCount || 0), 0);
                  const quota = event.tickets.reduce((acc, t) => acc + t.quota, 0);

                  return (
                    <tr key={event.id} className="hover:bg-slate-50">
                      <td className="p-3 font-bold text-slate-900 max-w-xs">{event.title}</td>
                      <td className="p-3 text-slate-600">{event.creatorName || 'Kreator'}</td>
                      <td className="p-3">{event.category}</td>
                      <td className="p-3 font-semibold text-slate-800">{sold} / {quota}</td>
                      <td className="p-3">
                        <button
                          onClick={() => handleToggleFeatured(event)}
                          className={`px-2.5 py-1 rounded-full text-[10px] font-bold flex items-center gap-1 transition-colors cursor-pointer ${
                            event.isFeatured ? 'bg-amber-100 text-amber-800 hover:bg-amber-200' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                          }`}
                        >
                          <Sparkles className="w-3 h-3" />
                          <span>{event.isFeatured ? 'Unggulan' : 'Standar'}</span>
                        </button>
                      </td>
                      <td className="p-3">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          event.status === 'published' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-700'
                        }`}>
                          {event.status.toUpperCase()}
                        </span>
                      </td>
                      <td className="p-3">
                        <div className="flex gap-2">
                          <button
                            onClick={() => handleToggleEventStatus(event, event.status === 'published' ? 'draft' : 'published')}
                            className="text-xs text-blue-600 font-bold hover:underline"
                          >
                            {event.status === 'published' ? 'Tutup Pendaftaran' : 'Buka Publik'}
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: PENGGUNA & MULTI-USER */}
      {activeTab === 'users' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
          <div className="border-b pb-4">
            <h2 className="text-base font-bold text-slate-900">Pengguna Platform & Manajemen Hak Akses</h2>
            <p className="text-xs text-slate-500">Mendukung multi-user: Super Admin, Kreator Event, dan Peserta / User</p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-700 font-bold border-b">
                <tr>
                  <th className="p-3">Nama</th>
                  <th className="p-3">Email</th>
                  <th className="p-3">Peran (Role)</th>
                  <th className="p-3">Autentikasi</th>
                  <th className="p-3">Organisasi</th>
                  <th className="p-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {users.map(u => (
                  <tr key={u.id} className="hover:bg-slate-50">
                    <td className="p-3 font-bold text-slate-900 flex items-center gap-2">
                      <img src={u.avatar} alt={u.name} className="w-7 h-7 rounded-full object-cover" />
                      <span>{u.name}</span>
                    </td>
                    <td className="p-3 text-slate-600">{u.email}</td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        u.role === 'admin'
                          ? 'bg-purple-100 text-purple-800'
                          : u.role === 'creator'
                          ? 'bg-blue-100 text-blue-800'
                          : 'bg-emerald-100 text-emerald-800'
                      }`}>
                        {u.role.toUpperCase()}
                      </span>
                    </td>
                    <td className="p-3 uppercase font-mono text-[10px] text-slate-500">{u.auth_provider || 'local'}</td>
                    <td className="p-3 text-slate-600">{u.organization || '-'}</td>
                    <td className="p-3">
                      <span className="text-emerald-600 font-bold text-[11px]">Aktif</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 4: TRANSAKSI & PEMBAYARAN */}
      {activeTab === 'transactions' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
          <div className="border-b pb-4">
            <h2 className="text-base font-bold text-slate-900">Seluruh Transaksi Penjualan Tiket</h2>
            <p className="text-xs text-slate-500">Daftar pesanan tiket lengkap dengan saluran pembayaran (QRIS, VA, Transfer)</p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-700 font-bold border-b">
                <tr>
                  <th className="p-3">Nomor Order</th>
                  <th className="p-3">Pembeli</th>
                  <th className="p-3">Event</th>
                  <th className="p-3">Tiket</th>
                  <th className="p-3">Metode Bayar</th>
                  <th className="p-3">Subtotal</th>
                  <th className="p-3">Komisi</th>
                  <th className="p-3">Total Tagihan</th>
                  <th className="p-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {orders.map(o => (
                  <tr key={o.id} className="hover:bg-slate-50">
                    <td className="p-3 font-mono font-bold text-blue-700">{o.orderNumber}</td>
                    <td className="p-3">
                      <span className="font-semibold text-slate-900 block">{o.buyerName}</span>
                      <span className="text-[10px] text-slate-500">{o.buyerPhone}</span>
                    </td>
                    <td className="p-3 truncate max-w-[150px]">{o.eventTitle}</td>
                    <td className="p-3 font-bold">{o.tickets.length} Tiket</td>
                    <td className="p-3">
                      <span className="font-semibold text-slate-800 block text-[11px]">{o.paymentChannel || o.paymentMethod}</span>
                      <span className="text-[10px] font-mono text-slate-400">{o.paymentReference || '-'}</span>
                    </td>
                    <td className="p-3">{formatRupiah(o.subtotal)}</td>
                    <td className="p-3 text-purple-700 font-medium">+{formatRupiah(o.platformFee)}</td>
                    <td className="p-3 font-extrabold text-slate-900">{formatRupiah(o.totalAmount)}</td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        o.paymentStatus === 'paid' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                      }`}>
                        {o.paymentStatus.toUpperCase()}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 5: PERSETUJUAN PAYOUT */}
      {activeTab === 'payouts' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
          <div className="border-b pb-4">
            <h2 className="text-base font-bold text-slate-900">Persetujuan & Pemrosesan Pencairan Dana Kreator</h2>
            <p className="text-xs text-slate-500">Super admin memverifikasi dan menyetujui transfer hasil penjualan tiket</p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-700 font-bold border-b">
                <tr>
                  <th className="p-3">Nama Kreator</th>
                  <th className="p-3">Event Terkait</th>
                  <th className="p-3">Rincian Dana & Potongan Platform</th>
                  <th className="p-3">Rekening Tujuan</th>
                  <th className="p-3">Waktu Pengajuan</th>
                  <th className="p-3">Status</th>
                  <th className="p-3">Tindakan Admin</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {payouts.map(p => {
                  const netVal = p.netAmount ?? p.amount;
                  const grossVal = p.grossAmount ?? p.amount;
                  const feeVal = p.platformFeeDeduction ?? (grossVal - netVal);

                  return (
                    <tr key={p.id} className="hover:bg-slate-50">
                      <td className="p-3 font-bold text-slate-900">{p.creatorName}</td>
                      <td className="p-3 text-slate-600">{p.eventTitle}</td>
                      <td className="p-3">
                        <div className="space-y-0.5">
                          <div className="font-extrabold text-emerald-700 text-sm">
                            {formatRupiah(netVal)} <span className="text-[10px] text-slate-400 font-normal">(Bersih Ditransfer)</span>
                          </div>
                          <div className="text-[11px] text-slate-500">
                            Kotor: <span className="font-semibold text-slate-700">{formatRupiah(grossVal)}</span>
                          </div>
                          <div className="text-[11px] text-red-600 font-medium">
                            Potongan Platform: -{formatRupiah(feeVal)}
                          </div>
                          {p.feeBreakdownText && (
                            <div className="text-[10px] text-slate-400 italic">
                              {p.feeBreakdownText}
                            </div>
                          )}
                        </div>
                      </td>
                      <td className="p-3">
                        <span className="font-semibold block">{p.bankName}</span>
                        <span className="font-mono text-slate-500">{p.accountNumber} ({p.accountName})</span>
                      </td>
                    <td className="p-3 text-slate-500">{new Date(p.createdAt).toLocaleDateString('id-ID')}</td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        p.status === 'approved' ? 'bg-emerald-100 text-emerald-800' : p.status === 'rejected' ? 'bg-red-100 text-red-800' : 'bg-amber-100 text-amber-800'
                      }`}>
                        {p.status.toUpperCase()}
                      </span>
                    </td>
                    <td className="p-3">
                      {p.status === 'pending' ? (
                        <div className="flex gap-2">
                          <button
                            onClick={() => handleApprovePayout(p.id)}
                            className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold"
                          >
                            Setujui & Transfer
                          </button>
                          <button
                            onClick={() => handleRejectPayout(p.id)}
                            className="px-3 py-1 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-lg text-xs font-bold"
                          >
                            Tolak
                          </button>
                        </div>
                      ) : (
                        <span className="text-slate-400 text-xs italic">Selesai diproses</span>
                      )}
                    </td>
                  </tr>
                );
              })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB: VERIFIKASI PEMBAYARAN MANUAL (SELURUH PLATFORM) */}
      {activeTab === 'manual-payments' && (
        <div className="space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-purple-100 text-purple-800">
                  Platform Oversight Hub
                </span>
                <span className="text-xs text-slate-400">•</span>
                <span className="text-xs text-slate-500">{adminPendingCount} Menunggu Verifikasi</span>
              </div>
              <h2 className="text-xl font-extrabold text-slate-900">
                Pusat Verifikasi Pembayaran Manual Seluruh Event
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 mt-1">
                Super admin dapat meninjau, menyetujui, atau menganulir verifikasi transfer manual untuk seluruh event.
              </p>
            </div>

            {/* Filters */}
            <div className="flex items-center gap-1.5 overflow-x-auto self-start sm:self-auto">
              <button
                onClick={() => setAdminManualFilter('all')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  adminManualFilter === 'all'
                    ? 'bg-purple-900 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                Semua ({adminManualOrders.length})
              </button>
              <button
                onClick={() => setAdminManualFilter('pending')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                  adminManualFilter === 'pending'
                    ? 'bg-amber-600 text-white shadow-xs'
                    : 'bg-amber-50 text-amber-700 hover:bg-amber-100 border border-amber-200'
                }`}
              >
                <span>Menunggu ({adminPendingCount})</span>
              </button>
              <button
                onClick={() => setAdminManualFilter('paid')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  adminManualFilter === 'paid'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                Disetujui ({adminManualOrders.filter(o => o.paymentStatus === 'paid').length})
              </button>
              <button
                onClick={() => setAdminManualFilter('rejected')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  adminManualFilter === 'rejected'
                    ? 'bg-red-600 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                Ditolak ({adminManualOrders.filter(o => o.paymentStatus === 'payment_rejected').length})
              </button>
            </div>
          </div>

          {/* Table of Manual Verification Orders */}
          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-700 font-bold border-b">
                  <tr>
                    <th className="p-3">Order & Waktu</th>
                    <th className="p-3">Event</th>
                    <th className="p-3">Pendaftar (Buyer)</th>
                    <th className="p-3">Rincian Bank Pengirim</th>
                    <th className="p-3">Total Transfer</th>
                    <th className="p-3">Bukti Struk</th>
                    <th className="p-3">Status</th>
                    <th className="p-3">Tindakan Super Admin</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {adminManualOrders
                    .filter(o => {
                      if (adminManualFilter === 'pending') return o.paymentStatus === 'pending_manual_verification';
                      if (adminManualFilter === 'paid') return o.paymentStatus === 'paid';
                      if (adminManualFilter === 'rejected') return o.paymentStatus === 'payment_rejected';
                      return true;
                    })
                    .map(order => {
                      const isPending = order.paymentStatus === 'pending_manual_verification';
                      const isPaid = order.paymentStatus === 'paid';
                      const isRejected = order.paymentStatus === 'payment_rejected';

                      return (
                        <tr key={order.id} className="hover:bg-slate-50">
                          <td className="p-3">
                            <span className="font-mono font-bold text-blue-700 block">{order.orderNumber}</span>
                            <span className="text-[10px] text-slate-400">
                              {new Date(order.createdAt).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                            </span>
                          </td>
                          <td className="p-3 truncate max-w-[150px] font-medium text-slate-900">
                            {order.eventTitle}
                          </td>
                          <td className="p-3">
                            <span className="font-bold text-slate-900 block">{order.buyerName}</span>
                            <span className="text-[10px] text-slate-500 block">{order.buyerPhone}</span>
                          </td>
                          <td className="p-3">
                            <span className="font-semibold text-slate-800 block">{order.senderBank || 'Bank Transfer'}</span>
                            <span className="text-[10px] text-slate-500 block">a.n {order.senderAccountName || order.buyerName}</span>
                          </td>
                          <td className="p-3 font-extrabold text-blue-700 text-sm">
                            {formatRupiah(order.totalAmount)}
                          </td>
                          <td className="p-3">
                            {order.paymentProofUrl ? (
                              <button
                                type="button"
                                onClick={() => setAdminPreviewProof(order)}
                                className="p-1 rounded-lg border border-slate-200 hover:border-blue-500 bg-white flex items-center gap-1.5 cursor-pointer"
                              >
                                <img
                                  src={order.paymentProofUrl}
                                  alt="Bukti"
                                  className="w-8 h-8 object-cover rounded-md"
                                />
                                <span className="text-[10px] font-bold text-blue-600">Zoom</span>
                              </button>
                            ) : (
                              <span className="text-[10px] text-slate-400 italic">Tidak ada foto</span>
                            )}
                          </td>
                          <td className="p-3">
                            <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              isPending
                                ? 'bg-amber-100 text-amber-800'
                                : isPaid
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-red-100 text-red-800'
                            }`}>
                              {isPending ? 'PENDING' : isPaid ? 'LUNAS' : 'DITOLAK'}
                            </span>
                          </td>
                          <td className="p-3">
                            {isPending ? (
                              <div className="flex items-center gap-1.5">
                                <button
                                  type="button"
                                  onClick={() => handleAdminApprove(order)}
                                  className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition-colors cursor-pointer"
                                >
                                  Setujui
                                </button>
                                <button
                                  type="button"
                                  onClick={() => {
                                    setAdminRejectOrder(order);
                                    setAdminRejectReason('Bukti transfer tidak sesuai atau mutasi bank belum terdata');
                                  }}
                                  className="px-2 py-1 bg-red-50 hover:bg-red-100 text-red-700 rounded-lg text-xs font-bold border border-red-200 cursor-pointer"
                                >
                                  Tolak
                                </button>
                              </div>
                            ) : (
                              <span className="text-slate-400 text-xs italic">
                                {isPaid ? 'Sudah Disetujui' : 'Sudah Ditolak'}
                              </span>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 6: MYSQL & HOSTING READY HUB */}
      {activeTab === 'database' && (
        <div className="space-y-6">
          {/* Status Box */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b pb-4">
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-2xl bg-blue-50 text-blue-600">
                  <Database className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-base">Status Database & Kesiapan Hosting</h3>
                  <p className="text-xs text-slate-500">
                    Sistem dirancang 100% kompatibel dengan MySQL 5.7 / 8.0, MariaDB, dan driver MySQLi cPanel
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <a
                  href="/api/download-package"
                  download="celebes-event-production.tar.gz"
                  className="px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-xs transition-colors cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>Unduh Paket Deploy (celebes-event-production.tar.gz)</span>
                </a>
                <button
                  type="button"
                  onClick={handleCopySql}
                  className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold flex items-center gap-2 transition-colors cursor-pointer border border-slate-300"
                >
                  {isCopiedSql ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4 text-slate-600" />}
                  <span>{isCopiedSql ? 'Tersalin ke Clipboard!' : 'Salin Seluruh Kueri SQL'}</span>
                </button>
                <a
                  href="/api/export-sql"
                  download="celebes_event_mysql.sql"
                  className="px-3.5 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-xs transition-colors cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>Unduh SQL</span>
                </a>
              </div>
            </div>

            {/* Banner Penjelasan Error #1044 cPanel */}
            <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900 space-y-2">
              <div className="flex items-center gap-2 font-bold text-amber-950">
                <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                <span>Penyelesaian Galat #1044 di phpMyAdmin cPanel:</span>
              </div>
              <p className="text-[11px] leading-relaxed text-amber-800">
                Di cPanel hosting (IDwebhost), database Anda bernama <strong>bergulir_celebeseventok</strong>. Galat <em>#1044 Access denied to celebes_event_db</em> terjadi jika menggunakan file SQL lama yang memiliki perintah <code className="bg-amber-100 px-1 rounded text-red-700">CREATE DATABASE celebes_event_db;</code>.
              </p>
              <div className="text-[11px] bg-white/70 p-2.5 rounded-lg border border-amber-200 font-medium">
                ✅ <strong>Solusi Mudah (1 Detik):</strong> Buka tab <strong>SQL</strong> di phpMyAdmin (pastikan sedang membuka basis data <em>bergulir_celebeseventok</em>), lalu klik tombol <strong>"Salin Seluruh Kueri SQL"</strong> di atas, paste di kotak SQL phpMyAdmin, lalu klik <strong>Kirim (Go)</strong>. Semua 12 tabel & data awal akan langsung terbuat sempurna!
              </div>
            </div>

            {/* Live Database Info Card */}
            {dbStatus && (
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs">
                <div>
                  <span className="text-slate-500 block text-[11px]">Mode Database:</span>
                  <span className="font-bold text-slate-900">{dbStatus.mode.toUpperCase()}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[11px]">Host Terdaftar:</span>
                  <span className="font-mono font-bold text-slate-800 truncate block">{dbStatus.host}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[11px]">Database Name:</span>
                  <span className="font-mono font-bold text-blue-700 truncate block">{dbStatus.database}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[11px]">Status Koneksi:</span>
                  <span className={`font-bold ${dbStatus.connected ? 'text-emerald-600' : 'text-slate-700'}`}>
                    {dbStatus.connected ? '✅ Terhubung ke MySQL' : '⚡ Local Resilient Engine Aktif'}
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* Test MySQL Connection & Setup Form */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-6 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
              <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                <Server className="w-4 h-4 text-purple-600" />
                Uji Koneksi MySQL Hosting Secara Interaktif
              </h3>
              <p className="text-xs text-slate-500">
                Masukkan parameter database hosting cPanel / VPS Anda untuk menguji koneksi langsung dari server.
              </p>

              <form onSubmit={handleTestMysql} className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-medium text-slate-700 mb-1">Host MySQL</label>
                    <input
                      type="text"
                      value={mysqlHost}
                      onChange={(e) => setMysqlHost(e.target.value)}
                      placeholder="localhost"
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-medium text-slate-700 mb-1">Nama Database</label>
                    <input
                      type="text"
                      value={mysqlDb}
                      onChange={(e) => setMysqlDb(e.target.value)}
                      placeholder="bergulir_celebeseventok"
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-medium text-slate-700 mb-1">User MySQL</label>
                    <input
                      type="text"
                      value={mysqlUser}
                      onChange={(e) => setMysqlUser(e.target.value)}
                      placeholder="bergulir_dbuser"
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-medium text-slate-700 mb-1">Password MySQL</label>
                    <input
                      type="password"
                      value={mysqlPass}
                      onChange={(e) => setMysqlPass(e.target.value)}
                      placeholder="Password database"
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isTestingMysql}
                  className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-bold flex items-center justify-center gap-2 cursor-pointer transition-colors"
                >
                  {isTestingMysql ? 'Menguji Koneksi...' : 'Uji Koneksi Sekarang'}
                </button>
              </form>

              {testResult && (
                <div className={`p-3 rounded-xl border text-xs flex items-center gap-2 ${
                  testResult.success ? 'bg-emerald-50 border-emerald-200 text-emerald-800' : 'bg-red-50 border-red-200 text-red-800'
                }`}>
                  {testResult.success ? <CheckCircle2 className="w-4 h-4 shrink-0" /> : <XCircle className="w-4 h-4 shrink-0" />}
                  <span>{testResult.message}</span>
                </div>
              )}
            </div>

            {/* Step-by-Step Deployment Guide Box */}
            <div className="lg:col-span-6 bg-slate-900 text-white rounded-2xl p-6 shadow-xs space-y-4">
              <div className="flex items-center gap-2">
                <FileCode className="w-5 h-5 text-blue-400" />
                <h3 className="font-bold text-sm text-white">Panduan Deploy ke cPanel Shared Hosting:</h3>
              </div>

              <ol className="list-decimal list-inside space-y-2 text-xs text-slate-300 leading-relaxed">
                <li>
                  <strong>Import Database:</strong> Unduh file <code className="text-emerald-400 bg-slate-800 px-1 py-0.5 rounded">schema.sql</code> lalu impor ke phpMyAdmin cPanel Anda.
                </li>
                <li>
                  <strong>Buka cPanel Node.js Selector:</strong> Klik <em>Setup Node.js App</em> di cPanel.
                </li>
                <li>
                  <strong>Pilih Versi Node:</strong> Pilih Node.js v18 / v20 / v22, set Application mode ke <em>Production</em>.
                </li>
                <li>
                  <strong>Upload & Install:</strong> Unggah file source code, klik <em>Run NPM Install</em>, lalu jalankan <code className="text-blue-300 bg-slate-800 px-1 py-0.5 rounded">npm run build</code>.
                </li>
                <li>
                  <strong>Set Environment:</strong> Masukkan kredensial MySQL di file <code className="text-emerald-400 bg-slate-800 px-1 py-0.5 rounded">.env</code> lalu klik <em>Restart Application</em>.
                </li>
              </ol>

              <div className="pt-2 border-t border-slate-800 text-[11px] text-slate-400">
                📄 Panduan lengkap untuk VPS (PM2/Nginx) dan Docker tersedia di file <strong>database/deployment_guide.md</strong>.
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 7: PENGATURAN PLATFORM & BRANDING */}
      {activeTab === 'settings' && (
        <form onSubmit={handleSavePlatformSettings} className="space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-purple-100 text-purple-800">
                  White-label & Brand Identity
                </span>
                <span className="text-xs text-slate-400">•</span>
                <span className="text-xs text-slate-500">Live Customizer</span>
              </div>
              <h2 className="text-xl font-extrabold text-slate-900">
                Pengaturan Platform, Identitas Logo & Media Sosial
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 mt-1">
                Ubah nama platform, logo, deskripsi aplikasi, tautan akun medsos resmi, dan banner promo. Perubahan langsung aktif di seluruh halaman!
              </p>
            </div>

            <button
              type="submit"
              disabled={isSavingSettings}
              className="px-5 py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white rounded-xl text-xs sm:text-sm font-bold shadow-md shadow-purple-500/25 flex items-center gap-2 cursor-pointer transition-all self-start sm:self-auto shrink-0"
            >
              <Save className="w-4 h-4" />
              <span>{isSavingSettings ? 'Menyimpan...' : 'Simpan Semua Perubahan'}</span>
            </button>
          </div>

          {settingsSuccessMessage && (
            <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-2xl text-xs sm:text-sm font-bold flex items-center gap-2 animate-in fade-in">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              <span>{settingsSuccessMessage}</span>
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Identitas Platform */}
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2 border-b pb-3">
                <Globe className="w-4 h-4 text-purple-600" />
                1. Identitas & Logo Platform
              </h3>

              <div className="space-y-3 text-xs">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Nama Platform / Aplikasi *</label>
                  <input
                    type="text"
                    required
                    value={settingsForm.platformName}
                    onChange={(e) => setSettingsForm({ ...settingsForm, platformName: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-slate-300 font-semibold text-slate-900 focus:ring-2 focus:ring-purple-500 focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Tagline Slogan *</label>
                  <input
                    type="text"
                    required
                    value={settingsForm.tagline}
                    onChange={(e) => setSettingsForm({ ...settingsForm, tagline: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-slate-300 text-slate-900 focus:ring-2 focus:ring-purple-500 focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">URL Logo Aplikasi (Gambar PNG/SVG/WebP) *</label>
                  <div className="flex gap-2 items-center">
                    <input
                      type="url"
                      required
                      value={settingsForm.logoUrl}
                      onChange={(e) => setSettingsForm({ ...settingsForm, logoUrl: e.target.value })}
                      className="flex-1 p-2.5 rounded-xl border border-slate-300 font-mono text-[11px] focus:ring-2 focus:ring-purple-500 focus:outline-hidden"
                    />
                    <div className="w-12 h-10 rounded-xl border border-slate-200 bg-slate-50 flex items-center justify-center p-1 shrink-0 overflow-hidden">
                      <img src={settingsForm.logoUrl} alt="Preview" className="max-w-full max-h-full object-contain" />
                    </div>
                  </div>
                  <span className="text-[10px] text-slate-400 mt-1 block">
                    Gunakan tautan logo transparan (rekomendasi rasio 1:1 atau 16:9).
                  </span>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Deskripsi Platform / Tentang Aplikasi *</label>
                  <textarea
                    rows={3}
                    required
                    value={settingsForm.description}
                    onChange={(e) => setSettingsForm({ ...settingsForm, description: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-slate-300 text-slate-900 focus:ring-2 focus:ring-purple-500 focus:outline-hidden leading-relaxed"
                  />
                </div>
              </div>
            </div>

            {/* Kontak Resmi Platform */}
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2 border-b pb-3">
                <Headphones className="w-4 h-4 text-purple-600" />
                2. Kontak Resmi & Dukungan Pengguna
              </h3>

              <div className="space-y-3 text-xs">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Email Layanan Pelanggan *</label>
                  <input
                    type="email"
                    required
                    value={settingsForm.contactEmail}
                    onChange={(e) => setSettingsForm({ ...settingsForm, contactEmail: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-slate-300 text-slate-900 focus:ring-2 focus:ring-purple-500 focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Nomor WhatsApp / Call Center *</label>
                  <input
                    type="text"
                    required
                    value={settingsForm.contactPhone}
                    onChange={(e) => setSettingsForm({ ...settingsForm, contactPhone: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-slate-300 text-slate-900 focus:ring-2 focus:ring-purple-500 focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Alamat Kantor Operasional *</label>
                  <textarea
                    rows={3}
                    required
                    value={settingsForm.contactAddress}
                    onChange={(e) => setSettingsForm({ ...settingsForm, contactAddress: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-slate-300 text-slate-900 focus:ring-2 focus:ring-purple-500 focus:outline-hidden"
                  />
                </div>
              </div>
            </div>

            {/* Akun Sosial Media Platform */}
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2 border-b pb-3">
                <LinkIcon className="w-4 h-4 text-purple-600" />
                3. Informasi & Link Akun Media Sosial
              </h3>

              <div className="space-y-3 text-xs">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Tautan Instagram</label>
                  <input
                    type="url"
                    value={settingsForm.socialLinks?.instagram || ''}
                    onChange={(e) =>
                      setSettingsForm({
                        ...settingsForm,
                        socialLinks: { ...settingsForm.socialLinks, instagram: e.target.value },
                      })
                    }
                    placeholder="https://instagram.com/akunresmi"
                    className="w-full p-2 rounded-xl border border-slate-300 text-slate-900"
                  />
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">Tautan WhatsApp Bisnis / Grup Komunitas</label>
                  <input
                    type="url"
                    value={settingsForm.socialLinks?.whatsapp || ''}
                    onChange={(e) =>
                      setSettingsForm({
                        ...settingsForm,
                        socialLinks: { ...settingsForm.socialLinks, whatsapp: e.target.value },
                      })
                    }
                    placeholder="https://wa.me/6281234567890"
                    className="w-full p-2 rounded-xl border border-slate-300 text-slate-900"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-medium text-slate-700 mb-1">TikTok</label>
                    <input
                      type="url"
                      value={settingsForm.socialLinks?.tiktok || ''}
                      onChange={(e) =>
                        setSettingsForm({
                          ...settingsForm,
                          socialLinks: { ...settingsForm.socialLinks, tiktok: e.target.value },
                        })
                      }
                      placeholder="https://tiktok.com/@akun"
                      className="w-full p-2 rounded-xl border border-slate-300 text-slate-900"
                    />
                  </div>
                  <div>
                    <label className="block font-medium text-slate-700 mb-1">YouTube</label>
                    <input
                      type="url"
                      value={settingsForm.socialLinks?.youtube || ''}
                      onChange={(e) =>
                        setSettingsForm({
                          ...settingsForm,
                          socialLinks: { ...settingsForm.socialLinks, youtube: e.target.value },
                        })
                      }
                      placeholder="https://youtube.com/@channel"
                      className="w-full p-2 rounded-xl border border-slate-300 text-slate-900"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="block font-medium text-slate-700 mb-1">Facebook</label>
                    <input
                      type="url"
                      value={settingsForm.socialLinks?.facebook || ''}
                      onChange={(e) =>
                        setSettingsForm({
                          ...settingsForm,
                          socialLinks: { ...settingsForm.socialLinks, facebook: e.target.value },
                        })
                      }
                      placeholder="https://facebook.com/fanpage"
                      className="w-full p-2 rounded-xl border border-slate-300 text-slate-900"
                    />
                  </div>
                  <div>
                    <label className="block font-medium text-slate-700 mb-1">X (Twitter)</label>
                    <input
                      type="url"
                      value={settingsForm.socialLinks?.twitter || ''}
                      onChange={(e) =>
                        setSettingsForm({
                          ...settingsForm,
                          socialLinks: { ...settingsForm.socialLinks, twitter: e.target.value },
                        })
                      }
                      placeholder="https://x.com/username"
                      className="w-full p-2 rounded-xl border border-slate-300 text-slate-900"
                    />
                  </div>
                  <div>
                    <label className="block font-medium text-slate-700 mb-1">LinkedIn</label>
                    <input
                      type="url"
                      value={settingsForm.socialLinks?.linkedin || ''}
                      onChange={(e) =>
                        setSettingsForm({
                          ...settingsForm,
                          socialLinks: { ...settingsForm.socialLinks, linkedin: e.target.value },
                        })
                      }
                      placeholder="https://linkedin.com/company/nama"
                      className="w-full p-2 rounded-xl border border-slate-300 text-slate-900"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Tampilan Beranda (GoEvent.id Style Customizer) */}
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2 border-b pb-3">
                <Image className="w-4 h-4 text-purple-600" />
                4. Tampilan Beranda & Banner Utama (Celebes Event Style)
              </h3>

              <div className="space-y-3 text-xs">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Headline Utama Beranda *</label>
                  <input
                    type="text"
                    required
                    value={settingsForm.heroHeadline}
                    onChange={(e) => setSettingsForm({ ...settingsForm, heroHeadline: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-slate-300 text-slate-900 focus:ring-2 focus:ring-purple-500 focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Subheadline Penjelas *</label>
                  <textarea
                    rows={2}
                    required
                    value={settingsForm.heroSubheadline}
                    onChange={(e) => setSettingsForm({ ...settingsForm, heroSubheadline: e.target.value })}
                    className="w-full p-2.5 rounded-xl border border-slate-300 text-slate-900 focus:ring-2 focus:ring-purple-500 focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">URL Background Banner Hero *</label>
                  <div className="flex gap-2 items-center">
                    <input
                      type="url"
                      required
                      value={settingsForm.heroBannerImage}
                      onChange={(e) => setSettingsForm({ ...settingsForm, heroBannerImage: e.target.value })}
                      className="flex-1 p-2.5 rounded-xl border border-slate-300 font-mono text-[11px] text-slate-900"
                    />
                    <img
                      src={settingsForm.heroBannerImage}
                      alt="Hero Preview"
                      className="w-14 h-10 object-cover rounded-lg border border-slate-200 shrink-0"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Teks Pengumuman Promo / Flash Banner</label>
                  <input
                    type="text"
                    value={settingsForm.announcementText || ''}
                    onChange={(e) => setSettingsForm({ ...settingsForm, announcementText: e.target.value })}
                    placeholder="Contoh: Promo Spesial: Gunakan kode TIKETHEMAT untuk diskon 15%!"
                    className="w-full p-2.5 rounded-xl border border-slate-300 text-slate-900"
                  />
                </div>
              </div>
            </div>

            {/* SEKSI 5: PENGATURAN POTONGAN KOMISI PLATFORM (FEE CONFIG) */}
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4 lg:col-span-2">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b pb-3">
                <div className="flex items-center gap-2">
                  <Percent className="w-5 h-5 text-emerald-600" />
                  <div>
                    <h3 className="text-sm font-bold text-slate-900">5. Pengaturan Potongan Komisi Platform (Platform Fee)</h3>
                    <p className="text-xs text-slate-500">Atur potongan dari event berbayar atau penarikan dana kreator (misal 2% atau Rp 2.000 tetap)</p>
                  </div>
                </div>
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800 self-start sm:self-auto">
                  {settingsForm.feeConfig?.feeType === 'percentage'
                    ? `Aktif: ${settingsForm.feeConfig.percentageValue}% Komisi`
                    : `Aktif: Rp${settingsForm.feeConfig?.fixedValue.toLocaleString('id-ID')} / Tiket`}
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
                <div className="space-y-4">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1.5">Model / Tipe Potongan Komisi *</label>
                    <div className="grid grid-cols-2 gap-3">
                      <label className={`p-3 rounded-xl border flex items-center gap-2 cursor-pointer transition-all ${
                        settingsForm.feeConfig?.feeType === 'percentage'
                          ? 'border-emerald-600 bg-emerald-50 text-emerald-900 font-bold'
                          : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                      }`}>
                        <input
                          type="radio"
                          name="feeType"
                          value="percentage"
                          checked={settingsForm.feeConfig?.feeType === 'percentage'}
                          onChange={() =>
                            setSettingsForm({
                              ...settingsForm,
                              feeConfig: {
                                ...(settingsForm.feeConfig || DEFAULT_PLATFORM_SETTINGS.feeConfig),
                                feeType: 'percentage',
                              },
                            })
                          }
                          className="text-emerald-600"
                        />
                        <span>Persentase (%)</span>
                      </label>

                      <label className={`p-3 rounded-xl border flex items-center gap-2 cursor-pointer transition-all ${
                        settingsForm.feeConfig?.feeType === 'fixed'
                          ? 'border-emerald-600 bg-emerald-50 text-emerald-900 font-bold'
                          : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                      }`}>
                        <input
                          type="radio"
                          name="feeType"
                          value="fixed"
                          checked={settingsForm.feeConfig?.feeType === 'fixed'}
                          onChange={() =>
                            setSettingsForm({
                              ...settingsForm,
                              feeConfig: {
                                ...(settingsForm.feeConfig || DEFAULT_PLATFORM_SETTINGS.feeConfig),
                                feeType: 'fixed',
                              },
                            })
                          }
                          className="text-emerald-600"
                        />
                        <span>Nominal Tetap (Rp)</span>
                      </label>
                    </div>
                  </div>

                  {settingsForm.feeConfig?.feeType === 'percentage' ? (
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">Besaran Persentase Potongan (%) *</label>
                      <div className="relative">
                        <input
                          type="number"
                          step="0.1"
                          min="0"
                          max="50"
                          required
                          value={settingsForm.feeConfig?.percentageValue ?? 2}
                          onChange={(e) =>
                            setSettingsForm({
                              ...settingsForm,
                              feeConfig: {
                                ...(settingsForm.feeConfig || DEFAULT_PLATFORM_SETTINGS.feeConfig),
                                percentageValue: parseFloat(e.target.value) || 0,
                              },
                            })
                          }
                          className="w-full p-2.5 rounded-xl border border-slate-300 text-slate-900 font-bold focus:ring-2 focus:ring-emerald-500"
                        />
                        <span className="absolute right-3.5 top-2.5 font-bold text-slate-400">%</span>
                      </div>
                      <span className="text-[10px] text-slate-400 mt-1 block">
                        Contoh: 2% berarti Rp20.000 dipotong dari setiap pencairan Rp1.000.000.
                      </span>
                    </div>
                  ) : (
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">Nominal Potongan Tetap (Rp) *</label>
                      <input
                        type="number"
                        min="0"
                        step="500"
                        required
                        value={settingsForm.feeConfig?.fixedValue ?? 2000}
                        onChange={(e) =>
                          setSettingsForm({
                            ...settingsForm,
                            feeConfig: {
                              ...(settingsForm.feeConfig || DEFAULT_PLATFORM_SETTINGS.feeConfig),
                              fixedValue: parseInt(e.target.value) || 0,
                            },
                          })
                        }
                        className="w-full p-2.5 rounded-xl border border-slate-300 text-slate-900 font-bold focus:ring-2 focus:ring-emerald-500"
                      />
                      <span className="text-[10px] text-slate-400 mt-1 block">
                        Contoh: Rp2.000 per tiket / transaksi penarikan dana.
                      </span>
                    </div>
                  )}

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Keterangan / Kebijakan Potongan Platform</label>
                    <input
                      type="text"
                      value={settingsForm.feeConfig?.description || ''}
                      onChange={(e) =>
                        setSettingsForm({
                          ...settingsForm,
                          feeConfig: {
                            ...(settingsForm.feeConfig || DEFAULT_PLATFORM_SETTINGS.feeConfig),
                            description: e.target.value,
                          },
                        })
                      }
                      placeholder="Contoh: Biaya komisi pemeliharaan platform tiket 2%"
                      className="w-full p-2.5 rounded-xl border border-slate-300 text-slate-900"
                    />
                  </div>
                </div>

                {/* Simulasi Live Transparansi */}
                <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 flex flex-col justify-between">
                  <div className="space-y-2">
                    <span className="font-bold text-slate-800 text-xs block flex items-center gap-1.5">
                      <Sparkles className="w-4 h-4 text-emerald-600" />
                      Simulasi Kalkulasi Transparansi (Contoh Pencairan Rp 5.000.000)
                    </span>
                    <p className="text-[11px] text-slate-500">
                      Rincian berikut adalah apa yang dilihat oleh kreator saat mengisi formulir penarikan dan apa yang tercatat di tabel admin:
                    </p>

                    {(() => {
                      const sampleGross = 5000000;
                      const isPct = settingsForm.feeConfig?.feeType === 'percentage';
                      const sampleDeduction = isPct 
                        ? Math.round(sampleGross * ((settingsForm.feeConfig?.percentageValue ?? 2) / 100))
                        : (settingsForm.feeConfig?.fixedValue ?? 2000);
                      const sampleNet = sampleGross - sampleDeduction;

                      return (
                        <div className="space-y-1.5 bg-white p-3 rounded-xl border border-slate-200 text-[11px] mt-2">
                          <div className="flex justify-between">
                            <span className="text-slate-600">Omzet Penarikan Kotor:</span>
                            <span className="font-semibold text-slate-900">{formatRupiah(sampleGross)}</span>
                          </div>
                          <div className="flex justify-between text-red-600">
                            <span>
                              Potongan Platform ({isPct ? `${settingsForm.feeConfig?.percentageValue}%` : `Tetap`}):
                            </span>
                            <span>-{formatRupiah(sampleDeduction)}</span>
                          </div>
                          <div className="flex justify-between text-emerald-700 font-extrabold text-xs pt-1.5 border-t border-slate-100">
                            <span>Dana Bersih Diterima Kreator:</span>
                            <span>{formatRupiah(sampleNet)}</span>
                          </div>
                        </div>
                      );
                    })()}
                  </div>

                  <p className="text-[10px] text-slate-400 mt-3 italic">
                    *Semua nominal potongan disimpan secara otomatis dan ditampilkan transparan kepada kreator & super admin.
                  </p>
                </div>
              </div>
            </div>

            {/* SEKSI 6: PENGATURAN 4 LANGKAH MUDAH DAPATKAN TIKET */}
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4 lg:col-span-2">
              <div className="border-b pb-3 flex items-center gap-2">
                <Layers className="w-5 h-5 text-blue-600" />
                <div>
                  <h3 className="text-sm font-bold text-slate-900">6. Pengaturan 4 Langkah Mudah Dapatkan Tiket (Celebes Event)</h3>
                  <p className="text-xs text-slate-500">Sesuaikan judul, nomor urut, dan deskripsi panduan yang tampil di beranda depan</p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
                {(settingsForm.howToSteps || DEFAULT_PLATFORM_SETTINGS.howToSteps).map((step, idx) => (
                  <div key={idx} className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/50 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <span className="w-7 h-7 rounded-lg bg-blue-600 text-white font-extrabold flex items-center justify-center text-xs">
                        {step.stepNumber}
                      </span>
                      <span className="text-[10px] font-bold text-slate-400">Langkah {idx + 1}</span>
                    </div>

                    <div>
                      <label className="block font-bold text-slate-700 mb-1 text-[11px]">Judul Langkah *</label>
                      <input
                        type="text"
                        required
                        value={step.title}
                        onChange={(e) => {
                          const updated = [...(settingsForm.howToSteps || DEFAULT_PLATFORM_SETTINGS.howToSteps)];
                          updated[idx] = { ...updated[idx], title: e.target.value };
                          setSettingsForm({ ...settingsForm, howToSteps: updated });
                        }}
                        className="w-full p-2 rounded-lg border border-slate-300 text-slate-900 font-bold bg-white"
                      />
                    </div>

                    <div>
                      <label className="block font-bold text-slate-700 mb-1 text-[11px]">Deskripsi Singkat *</label>
                      <textarea
                        rows={3}
                        required
                        value={step.description}
                        onChange={(e) => {
                          const updated = [...(settingsForm.howToSteps || DEFAULT_PLATFORM_SETTINGS.howToSteps)];
                          updated[idx] = { ...updated[idx], description: e.target.value };
                          setSettingsForm({ ...settingsForm, howToSteps: updated });
                        }}
                        className="w-full p-2 rounded-lg border border-slate-300 text-slate-900 bg-white"
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* SEKSI 7: PENGATURAN PAKET LAYANAN (PRICE LIST PAKET) */}
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4 lg:col-span-2">
              <div className="border-b pb-3 flex items-center gap-2">
                <FileText className="w-5 h-5 text-indigo-600" />
                <div>
                  <h3 className="text-sm font-bold text-slate-900">7. Pengaturan Paket Layanan (Price List Paket - Celebes Event)</h3>
                  <p className="text-xs text-slate-500">Kelola 3 paket layanan: Platform Only (Rp500rb), Event Berbayar (2%), dan On Site Registration (Rp2jt)</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-5 text-xs">
                {(settingsForm.servicePackages || DEFAULT_PLATFORM_SETTINGS.servicePackages).map((pkg, idx) => (
                  <div key={idx} className="p-4 rounded-2xl border border-slate-200 bg-slate-50/60 space-y-3 flex flex-col justify-between">
                    <div className="space-y-2.5">
                      <div className="flex items-center justify-between">
                        <span className="font-extrabold text-slate-900 text-sm">{pkg.name}</span>
                        {pkg.badge && (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-400 text-slate-950">
                            {pkg.badge}
                          </span>
                        )}
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block text-[10px] font-bold text-slate-600">Nominal / Tarif</label>
                          <input
                            type="text"
                            value={pkg.price}
                            onChange={(e) => {
                              const updated = [...(settingsForm.servicePackages || DEFAULT_PLATFORM_SETTINGS.servicePackages)];
                              updated[idx] = { ...updated[idx], price: e.target.value };
                              setSettingsForm({ ...settingsForm, servicePackages: updated });
                            }}
                            className="w-full p-1.5 rounded-lg border border-slate-300 font-extrabold text-blue-700 bg-white text-xs"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] font-bold text-slate-600">Satuan</label>
                          <input
                            type="text"
                            value={pkg.priceSub}
                            onChange={(e) => {
                              const updated = [...(settingsForm.servicePackages || DEFAULT_PLATFORM_SETTINGS.servicePackages)];
                              updated[idx] = { ...updated[idx], priceSub: e.target.value };
                              setSettingsForm({ ...settingsForm, servicePackages: updated });
                            }}
                            className="w-full p-1.5 rounded-lg border border-slate-300 text-slate-600 bg-white text-xs"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-[10px] font-bold text-slate-600">Deskripsi Paket</label>
                        <input
                          type="text"
                          value={pkg.description}
                          onChange={(e) => {
                            const updated = [...(settingsForm.servicePackages || DEFAULT_PLATFORM_SETTINGS.servicePackages)];
                            updated[idx] = { ...updated[idx], description: e.target.value };
                            setSettingsForm({ ...settingsForm, servicePackages: updated });
                          }}
                          className="w-full p-1.5 rounded-lg border border-slate-300 text-slate-900 bg-white text-xs"
                        />
                      </div>

                      <div>
                        <label className="block text-[10px] font-bold text-slate-600">Catatan Khusus (Keterangan)</label>
                        <textarea
                          rows={2}
                          value={pkg.note}
                          onChange={(e) => {
                            const updated = [...(settingsForm.servicePackages || DEFAULT_PLATFORM_SETTINGS.servicePackages)];
                            updated[idx] = { ...updated[idx], note: e.target.value };
                            setSettingsForm({ ...settingsForm, servicePackages: updated });
                          }}
                          className="w-full p-1.5 rounded-lg border border-slate-300 text-slate-700 bg-white text-xs"
                        />
                      </div>

                      <div>
                        <label className="block text-[10px] font-bold text-emerald-800">Fitur Termasuk (1 baris per fitur)</label>
                        <textarea
                          rows={3}
                          value={pkg.featuresIncluded.join('\n')}
                          onChange={(e) => {
                            const updated = [...(settingsForm.servicePackages || DEFAULT_PLATFORM_SETTINGS.servicePackages)];
                            updated[idx] = { ...updated[idx], featuresIncluded: e.target.value.split('\n') };
                            setSettingsForm({ ...settingsForm, servicePackages: updated });
                          }}
                          className="w-full p-1.5 rounded-lg border border-slate-300 text-slate-800 bg-white text-xs"
                        />
                      </div>

                      {pkg.organizerPrepared && (
                        <div>
                          <label className="block text-[10px] font-bold text-amber-800">Disiapkan Penyelenggara</label>
                          <textarea
                            rows={3}
                            value={pkg.organizerPrepared.join('\n')}
                            onChange={(e) => {
                              const updated = [...(settingsForm.servicePackages || DEFAULT_PLATFORM_SETTINGS.servicePackages)];
                              updated[idx] = { ...updated[idx], organizerPrepared: e.target.value.split('\n') };
                              setSettingsForm({ ...settingsForm, servicePackages: updated });
                            }}
                            className="w-full p-1.5 rounded-lg border border-slate-300 text-slate-800 bg-white text-xs"
                          />
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* SEKSI 8: PENGATURAN TENTANG KAMI (ABOUT US) */}
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4 lg:col-span-2">
              <div className="border-b pb-3 flex items-center gap-2">
                <Globe className="w-5 h-5 text-purple-600" />
                <div>
                  <h3 className="text-sm font-bold text-slate-900">8. Pengaturan Tentang Kami (About Us, Visi, Misi & Metrik)</h3>
                  <p className="text-xs text-slate-500">Kelola cerita platform, nilai perusahaan, serta 4 highlight metrik di beranda</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Judul Utama Seksi *</label>
                  <input
                    type="text"
                    required
                    value={settingsForm.aboutUs?.title || ''}
                    onChange={(e) =>
                      setSettingsForm({
                        ...settingsForm,
                        aboutUs: { ...(settingsForm.aboutUs || DEFAULT_PLATFORM_SETTINGS.aboutUs), title: e.target.value },
                      })
                    }
                    className="w-full p-2.5 rounded-xl border border-slate-300 text-slate-900"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Subtitle / Slogan Penjelas *</label>
                  <input
                    type="text"
                    required
                    value={settingsForm.aboutUs?.subtitle || ''}
                    onChange={(e) =>
                      setSettingsForm({
                        ...settingsForm,
                        aboutUs: { ...(settingsForm.aboutUs || DEFAULT_PLATFORM_SETTINGS.aboutUs), subtitle: e.target.value },
                      })
                    }
                    className="w-full p-2.5 rounded-xl border border-slate-300 text-slate-900"
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="block font-bold text-slate-700 mb-1">Cerita / Deskripsi Lengkap Tentang Kami *</label>
                  <textarea
                    rows={3}
                    required
                    value={settingsForm.aboutUs?.story || ''}
                    onChange={(e) =>
                      setSettingsForm({
                        ...settingsForm,
                        aboutUs: { ...(settingsForm.aboutUs || DEFAULT_PLATFORM_SETTINGS.aboutUs), story: e.target.value },
                      })
                    }
                    className="w-full p-2.5 rounded-xl border border-slate-300 text-slate-900 leading-relaxed"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Visi Platform *</label>
                  <textarea
                    rows={2}
                    required
                    value={settingsForm.aboutUs?.vision || ''}
                    onChange={(e) =>
                      setSettingsForm({
                        ...settingsForm,
                        aboutUs: { ...(settingsForm.aboutUs || DEFAULT_PLATFORM_SETTINGS.aboutUs), vision: e.target.value },
                      })
                    }
                    className="w-full p-2.5 rounded-xl border border-slate-300 text-slate-900"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Misi Platform *</label>
                  <textarea
                    rows={2}
                    required
                    value={settingsForm.aboutUs?.mission || ''}
                    onChange={(e) =>
                      setSettingsForm({
                        ...settingsForm,
                        aboutUs: { ...(settingsForm.aboutUs || DEFAULT_PLATFORM_SETTINGS.aboutUs), mission: e.target.value },
                      })
                    }
                    className="w-full p-2.5 rounded-xl border border-slate-300 text-slate-900"
                  />
                </div>
              </div>
            </div>

            {/* SEKSI 9: PENGATURAN GALERI DOKUMENTASI KEGIATAN */}
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4 lg:col-span-2">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b pb-3">
                <div className="flex items-center gap-2">
                  <Image className="w-5 h-5 text-amber-600" />
                  <div>
                    <h3 className="text-sm font-bold text-slate-900">9. Pengaturan Galeri Dokumentasi Kegiatan Event</h3>
                    <p className="text-xs text-slate-500">Foto dokumentasi kegiatan yang tampil di halaman depan beranda</p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    const currentGal = settingsForm.gallery || DEFAULT_PLATFORM_SETTINGS.gallery;
                    const newId = `gal-${Date.now()}`;
                    setSettingsForm({
                      ...settingsForm,
                      gallery: [
                        ...currentGal,
                        {
                          id: newId,
                          title: 'Dokumentasi Event Baru',
                          category: 'Festival & Musik',
                          imageUrl: 'https://images.unsplash.com/photo-1501386761578-eac5c94b800a?auto=format&fit=crop&w=800&q=80',
                        },
                      ],
                    });
                  }}
                  className="px-3 py-1.5 bg-blue-50 text-blue-700 hover:bg-blue-100 rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer self-start sm:self-auto"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Tambah Foto Galeri</span>
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 text-xs">
                {(settingsForm.gallery || DEFAULT_PLATFORM_SETTINGS.gallery).map((item, idx) => (
                  <div key={item.id || idx} className="p-3 rounded-xl border border-slate-200 bg-slate-50 space-y-2">
                    <div className="aspect-16/9 rounded-lg overflow-hidden bg-slate-200 relative">
                      <img src={item.imageUrl} alt={item.title} className="w-full h-full object-cover" />
                      <button
                        type="button"
                        onClick={() => {
                          const updated = (settingsForm.gallery || DEFAULT_PLATFORM_SETTINGS.gallery).filter((_, i) => i !== idx);
                          setSettingsForm({ ...settingsForm, gallery: updated });
                        }}
                        className="absolute top-2 right-2 p-1.5 rounded-lg bg-red-600/80 text-white hover:bg-red-700 cursor-pointer"
                        title="Hapus Foto"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <input
                      type="url"
                      value={item.imageUrl}
                      onChange={(e) => {
                        const updated = [...(settingsForm.gallery || DEFAULT_PLATFORM_SETTINGS.gallery)];
                        updated[idx] = { ...updated[idx], imageUrl: e.target.value };
                        setSettingsForm({ ...settingsForm, gallery: updated });
                      }}
                      placeholder="URL Gambar..."
                      className="w-full p-1.5 rounded-lg border border-slate-300 text-[11px] bg-white font-mono"
                    />

                    <div className="grid grid-cols-2 gap-2">
                      <input
                        type="text"
                        value={item.title}
                        onChange={(e) => {
                          const updated = [...(settingsForm.gallery || DEFAULT_PLATFORM_SETTINGS.gallery)];
                          updated[idx] = { ...updated[idx], title: e.target.value };
                          setSettingsForm({ ...settingsForm, gallery: updated });
                        }}
                        placeholder="Judul Event"
                        className="w-full p-1.5 rounded-lg border border-slate-300 text-xs bg-white font-semibold"
                      />
                      <input
                        type="text"
                        value={item.category}
                        onChange={(e) => {
                          const updated = [...(settingsForm.gallery || DEFAULT_PLATFORM_SETTINGS.gallery)];
                          updated[idx] = { ...updated[idx], category: e.target.value };
                          setSettingsForm({ ...settingsForm, gallery: updated });
                        }}
                        placeholder="Kategori"
                        className="w-full p-1.5 rounded-lg border border-slate-300 text-xs bg-white"
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </form>
      )}

      {/* TAB 8: GATEWAY & API QRIS */}
      {activeTab === 'qris-api' && (
        <form onSubmit={handleSaveQrisConfig} className="space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800">
                  Bank Indonesia QRIS MPM & Aggregator Ready
                </span>
                <span className="text-xs text-slate-400">•</span>
                <span className="text-xs text-slate-500">Auto Payment Settlement</span>
              </div>
              <h2 className="text-xl font-extrabold text-slate-900">
                Konfigurasi Gateway & API Pembayaran QRIS Otomatis
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 mt-1">
                Masukkan API Key, Merchant ID, dan Secret Key untuk mengaktifkan pemindaian QRIS dinamis/otomatis dari BCA, Mandiri, BRI, BNI, GoPay, OVO, ShopeePay, dan DANA.
              </p>
            </div>

            <div className="flex items-center gap-2 self-start sm:self-auto shrink-0">
              <button
                type="button"
                onClick={handleTestQrisPing}
                className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs sm:text-sm transition-colors cursor-pointer"
              >
                Uji Koneksi (Ping Gateway)
              </button>
              <button
                type="submit"
                disabled={isSavingQris}
                className="px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 text-white rounded-xl text-xs sm:text-sm font-bold shadow-md shadow-emerald-600/25 flex items-center gap-2 cursor-pointer transition-all"
              >
                <Save className="w-4 h-4" />
                <span>{isSavingQris ? 'Menyimpan...' : 'Simpan Kredensial QRIS'}</span>
              </button>
            </div>
          </div>

          {qrisTestResult && (
            <div className="p-4 bg-slate-900 text-white rounded-2xl text-xs font-mono border border-slate-800 flex items-start gap-3">
              <QrCode className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
              <div className="flex-1">
                <span className="font-bold text-emerald-400 block mb-0.5">Diagnostik API Gateway QRIS:</span>
                <p className="text-slate-300 leading-relaxed">{qrisTestResult}</p>
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Setting Form */}
            <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2 border-b pb-3">
                <QrCode className="w-4 h-4 text-emerald-600" />
                Kredensial Akun Merchant & API Provider
              </h3>

              <div className="space-y-4 text-xs">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Penyedia Layanan / Payment Gateway *</label>
                  <select
                    value={settingsForm.qrisConfig.provider}
                    onChange={(e) =>
                      setSettingsForm({
                        ...settingsForm,
                        qrisConfig: {
                          ...settingsForm.qrisConfig,
                          provider: e.target.value as any,
                        },
                      })
                    }
                    className="w-full p-2.5 rounded-xl border border-slate-300 text-slate-900 font-bold focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="midtrans">Midtrans Payment Gateway (QRIS, VA BCA, Mandiri, BRI, BNI)</option>
                    <option value="xendit">Xendit Indonesia (QRIS Dinamis, E-Wallet, VA)</option>
                    <option value="doku">DOKU Payment Solution (QRIS & Multi-bank)</option>
                    <option value="bi_qris">Bank Indonesia QRIS MPM Standar Nasional</option>
                    <option value="manual">Sistem Manual / Semi-Automated Only</option>
                  </select>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Merchant ID *</label>
                    <input
                      type="text"
                      required
                      value={settingsForm.qrisConfig.merchantId}
                      onChange={(e) =>
                        setSettingsForm({
                          ...settingsForm,
                          qrisConfig: { ...settingsForm.qrisConfig, merchantId: e.target.value },
                        })
                      }
                      placeholder="Contoh: M-CELEBES-882190"
                      className="w-full p-2.5 rounded-xl border border-slate-300 font-mono text-slate-900"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Client Key / Public Key *</label>
                    <input
                      type="text"
                      required
                      value={settingsForm.qrisConfig.clientKey}
                      onChange={(e) =>
                        setSettingsForm({
                          ...settingsForm,
                          qrisConfig: { ...settingsForm.qrisConfig, clientKey: e.target.value },
                        })
                      }
                      placeholder="Contoh: SB-Mid-client-XXXXX"
                      className="w-full p-2.5 rounded-xl border border-slate-300 font-mono text-slate-900"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Server Key / Secret API Key *</label>
                  <input
                    type="password"
                    required
                    value={settingsForm.qrisConfig.serverKey}
                    onChange={(e) =>
                      setSettingsForm({
                        ...settingsForm,
                        qrisConfig: { ...settingsForm.qrisConfig, serverKey: e.target.value },
                      })
                    }
                    placeholder="Contoh: SB-Mid-server-YYYYY"
                    className="w-full p-2.5 rounded-xl border border-slate-300 font-mono text-slate-900"
                  />
                  <span className="text-[10px] text-slate-400 mt-1 block">
                    Kunci ini disimpan aman di sisi server untuk memvalidasi notifikasi webhook pembayaran lunas.
                  </span>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Webhook URL Callback Notification</label>
                  <input
                    type="text"
                    readOnly
                    value={settingsForm.qrisConfig.webhookUrl || `${window.location.origin}/api/webhooks/qris`}
                    className="w-full p-2.5 rounded-xl border border-slate-200 bg-slate-50 font-mono text-slate-600 text-[11px]"
                  />
                  <span className="text-[10px] text-slate-400 mt-1 block">
                    Salin URL ini dan tempel di dashboard merchant penyedia pembayaran Anda pada menu Webhook Settings.
                  </span>
                </div>

                {/* Toggles */}
                <div className="pt-2 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <label className="flex items-center gap-3 p-3 rounded-xl border border-slate-200 bg-slate-50 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settingsForm.qrisConfig.isSandbox}
                      onChange={(e) =>
                        setSettingsForm({
                          ...settingsForm,
                          qrisConfig: { ...settingsForm.qrisConfig, isSandbox: e.target.checked },
                        })
                      }
                      className="w-4 h-4 text-emerald-600 rounded"
                    />
                    <div>
                      <span className="font-bold text-slate-800 block text-xs">Sandbox Mode (Uji Coba)</span>
                      <span className="text-[10px] text-slate-500">Gunakan simulator tanpa transaksi uang asli</span>
                    </div>
                  </label>

                  <label className="flex items-center gap-3 p-3 rounded-xl border border-slate-200 bg-slate-50 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settingsForm.qrisConfig.isEnabled}
                      onChange={(e) =>
                        setSettingsForm({
                          ...settingsForm,
                          qrisConfig: { ...settingsForm.qrisConfig, isEnabled: e.target.checked },
                        })
                      }
                      className="w-4 h-4 text-emerald-600 rounded"
                    />
                    <div>
                      <span className="font-bold text-slate-800 block text-xs">Aktifkan QRIS di Checkout</span>
                      <span className="text-[10px] text-slate-500">Tampilkan opsi pembayaran QRIS pada peserta</span>
                    </div>
                  </label>
                </div>
              </div>
            </div>

            {/* Info Box */}
            <div className="lg:col-span-5 bg-gradient-to-br from-slate-900 to-indigo-950 text-white rounded-2xl p-6 shadow-xs space-y-4">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-emerald-400" />
                <h4 className="font-bold text-sm text-white">Panduan Integrasi Gateway QRIS</h4>
              </div>

              <div className="space-y-3 text-xs text-slate-300 leading-relaxed">
                <p>
                  Celebes Event mendukung penerimaan pembayaran otomatis berstandar <strong>QRIS Nasional</strong> (Bank Indonesia). Peserta dapat membayar menggunakan aplikasi m-Banking manapun:
                </p>
                <div className="grid grid-cols-2 gap-2 text-[11px] font-semibold">
                  <div className="bg-white/10 p-2 rounded-lg">• BCA Mobile & Sakuku</div>
                  <div className="bg-white/10 p-2 rounded-lg">• Livin' Mandiri</div>
                  <div className="bg-white/10 p-2 rounded-lg">• BRImo (Bank BRI)</div>
                  <div className="bg-white/10 p-2 rounded-lg">• BNI Mobile</div>
                  <div className="bg-white/10 p-2 rounded-lg">• GoPay & OVO</div>
                  <div className="bg-white/10 p-2 rounded-lg">• ShopeePay & DANA</div>
                </div>

                <div className="p-3 bg-emerald-500/20 border border-emerald-400/30 rounded-xl text-emerald-200 text-xs">
                  ✅ Tiket otomatis diterbitkan secara instan setelah scanner QRIS pembeli mengonfirmasi pembayaran sukses.
                </div>
              </div>
            </div>
          </div>
        </form>
      )}

      {/* TAB 9: PUSAT BANTUAN & KENDALA PENGGUNA */}
      {activeTab === 'support-desk' && (
        <div className="space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-blue-100 text-blue-800">
                  Layanan Pengaduan & CS Helpdesk
                </span>
                <span className="text-xs text-slate-400">•</span>
                <span className="text-xs text-slate-500">
                  {supportTickets.filter(t => t.status === 'open').length} Menunggu Tanggapan
                </span>
              </div>
              <h2 className="text-xl font-extrabold text-slate-900">
                Pusat Bantuan & Pemantauan Laporan Kendala
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 mt-1">
                Super admin dapat meninjau keluhan tiket/pembayaran peserta, membalas solusi, dan memperbarui status tiket kendala.
              </p>
            </div>

            {/* Filter status */}
            <div className="flex items-center gap-1.5 overflow-x-auto self-start sm:self-auto">
              <button
                onClick={() => setSupportFilter('all')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  supportFilter === 'all'
                    ? 'bg-purple-900 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                Semua ({supportTickets.length})
              </button>
              <button
                onClick={() => setSupportFilter('open')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  supportFilter === 'open'
                    ? 'bg-amber-600 text-white shadow-xs'
                    : 'bg-amber-50 text-amber-700 hover:bg-amber-100 border border-amber-200'
                }`}
              >
                Menunggu ({supportTickets.filter(t => t.status === 'open').length})
              </button>
              <button
                onClick={() => setSupportFilter('in_progress')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  supportFilter === 'in_progress'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                Diproses ({supportTickets.filter(t => t.status === 'in_progress').length})
              </button>
              <button
                onClick={() => setSupportFilter('resolved')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  supportFilter === 'resolved'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                Selesai ({supportTickets.filter(t => t.status === 'resolved').length})
              </button>
            </div>
          </div>

          {/* Support Tickets Table */}
          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-700 font-bold border-b">
                  <tr>
                    <th className="p-3">No. Tiket</th>
                    <th className="p-3">Pelapor</th>
                    <th className="p-3">Kategori & Urgensi</th>
                    <th className="p-3">Subjek & Masalah</th>
                    <th className="p-3">Waktu Masuk</th>
                    <th className="p-3">Status</th>
                    <th className="p-3">Tindakan Super Admin</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {supportTickets
                    .filter(t => (supportFilter === 'all' ? true : t.status === supportFilter))
                    .map(ticket => (
                      <tr key={ticket.id} className="hover:bg-slate-50">
                        <td className="p-3 font-mono font-bold text-blue-700">{ticket.ticketNumber}</td>
                        <td className="p-3">
                          <span className="font-bold text-slate-900 block">{ticket.name}</span>
                          <span className="text-[10px] text-slate-500 block">{ticket.email}</span>
                          {ticket.phone && <span className="text-[10px] text-slate-400 block">{ticket.phone}</span>}
                        </td>
                        <td className="p-3">
                          <span className="font-semibold text-slate-800 capitalize block">{ticket.category}</span>
                          <span
                            className={`inline-block px-1.5 py-0.2 rounded text-[9px] font-bold uppercase ${
                              ticket.priority === 'tinggi'
                                ? 'bg-red-100 text-red-700'
                                : ticket.priority === 'sedang'
                                ? 'bg-amber-100 text-amber-700'
                                : 'bg-slate-100 text-slate-600'
                            }`}
                          >
                            Urgensi: {ticket.priority}
                          </span>
                        </td>
                        <td className="p-3 max-w-xs">
                          <span className="font-bold text-slate-900 block truncate">{ticket.subject}</span>
                          <p className="text-[11px] text-slate-600 line-clamp-2 mt-0.5">{ticket.message}</p>
                          {ticket.adminReply && (
                            <div className="mt-1 text-[10px] text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                              <strong>Balasan:</strong> {ticket.adminReply}
                            </div>
                          )}
                        </td>
                        <td className="p-3 text-slate-500 whitespace-nowrap">
                          {new Date(ticket.createdAt).toLocaleDateString('id-ID', {
                            day: 'numeric',
                            month: 'short',
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </td>
                        <td className="p-3">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                              ticket.status === 'resolved'
                                ? 'bg-emerald-100 text-emerald-800'
                                : ticket.status === 'in_progress'
                                ? 'bg-blue-100 text-blue-800'
                                : 'bg-amber-100 text-amber-800'
                            }`}
                          >
                            {ticket.status === 'resolved'
                              ? 'SELESAI'
                              : ticket.status === 'in_progress'
                              ? 'DIPROSES'
                              : 'MENUNGGU'}
                          </span>
                        </td>
                        <td className="p-3">
                          <button
                            onClick={() => {
                              setSelectedTicketForReply(ticket);
                              setAdminReplyText(ticket.adminReply || '');
                              setAdminReplyStatus(ticket.status === 'resolved' ? 'resolved' : 'in_progress');
                            }}
                            className="px-3 py-1 bg-purple-50 hover:bg-purple-100 text-purple-700 font-bold rounded-lg border border-purple-200 text-xs flex items-center gap-1 cursor-pointer"
                          >
                            <MessageSquare className="w-3.5 h-3.5" />
                            <span>Tanggapi</span>
                          </button>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* MODAL BALAS KENDALA OLEH SUPER ADMIN */}
      {selectedTicketForReply && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col animate-in fade-in zoom-in-95 duration-150">
            <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
              <div>
                <span className="text-[10px] text-purple-400 font-bold uppercase tracking-wider block">
                  Tanggapan Pusat Bantuan
                </span>
                <h4 className="font-bold text-sm text-white">
                  Tiket #{selectedTicketForReply.ticketNumber} • {selectedTicketForReply.name}
                </h4>
              </div>
              <button
                onClick={() => setSelectedTicketForReply(null)}
                className="p-1 rounded-xl text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitAdminReply} className="p-6 space-y-4 flex-1 overflow-y-auto text-xs">
              {/* Detail Pertanyaan Pelapor */}
              <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-1.5">
                <div className="flex justify-between font-bold text-slate-900">
                  <span>{selectedTicketForReply.subject}</span>
                  <span className="capitalize text-slate-500 font-normal">Kategori: {selectedTicketForReply.category}</span>
                </div>
                <p className="text-slate-600 whitespace-pre-line leading-relaxed">{selectedTicketForReply.message}</p>
                <div className="text-[10px] text-slate-400 pt-1 border-t border-slate-200">
                  Pelapor: {selectedTicketForReply.name} ({selectedTicketForReply.email}) {selectedTicketForReply.phone && `• ${selectedTicketForReply.phone}`}
                </div>
              </div>

              {/* Form Balasan Admin */}
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Pesan Tanggapan / Solusi Resmi Super Admin *
                </label>
                <textarea
                  rows={4}
                  required
                  value={adminReplyText}
                  onChange={(e) => setAdminReplyText(e.target.value)}
                  placeholder="Tuliskan solusi, link tiket, atau konfirmasi penyelesaian kendala di sini..."
                  className="w-full p-2.5 rounded-xl border border-slate-300 text-slate-900 focus:ring-2 focus:ring-purple-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Perbarui Status Tiket Kendala</label>
                <select
                  value={adminReplyStatus}
                  onChange={(e) => setAdminReplyStatus(e.target.value as any)}
                  className="w-full p-2.5 rounded-xl border border-slate-300 text-slate-900 font-bold"
                >
                  <option value="in_progress">Sedang Diproses / Butuh Verifikasi Lanjutan</option>
                  <option value="resolved">Selesai (Resolved) - Masalah Teratasi</option>
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setSelectedTicketForReply(null)}
                  className="px-4 py-2 text-xs font-bold text-slate-600 hover:text-slate-900 border border-slate-300 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingReply}
                  className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-1.5 cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{isSubmittingReply ? 'Mengirim...' : 'Kirim Tanggapan Bantuan'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL PREVIEW BUKTI TRANSFER SUPER ADMIN */}
      {adminPreviewProof && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-xl w-full max-h-[92vh] shadow-2xl border border-slate-200 flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between shrink-0">
              <div>
                <span className="text-[10px] text-purple-400 font-bold uppercase tracking-wider block">
                  Super Admin • Verifikasi Bukti Struk
                </span>
                <h4 className="font-bold text-sm text-white">
                  Order {adminPreviewProof.orderNumber} • {formatRupiah(adminPreviewProof.totalAmount)}
                </h4>
              </div>
              <button
                onClick={() => setAdminPreviewProof(null)}
                className="p-1 rounded-xl text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-4 text-center">
              <div className="bg-slate-100 rounded-2xl p-2 max-h-[50vh] overflow-hidden flex items-center justify-center border border-slate-200">
                <img
                  src={adminPreviewProof.paymentProofUrl}
                  alt="Bukti Transfer Penuh"
                  className="max-h-[48vh] w-auto object-contain rounded-xl shadow-xs"
                />
              </div>

              <div className="p-4 bg-slate-50 rounded-2xl text-left text-xs space-y-1.5 border border-slate-200">
                <div className="flex justify-between">
                  <span className="text-slate-500">Nama Pendaftar:</span>
                  <span className="font-bold text-slate-800">{adminPreviewProof.buyerName} ({adminPreviewProof.buyerEmail})</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Event:</span>
                  <span className="font-bold text-slate-800">{adminPreviewProof.eventTitle}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Bank Pengirim:</span>
                  <span className="font-bold text-slate-800">{adminPreviewProof.senderBank}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Nama Pemilik Rekening:</span>
                  <span className="font-bold text-slate-800">{adminPreviewProof.senderAccountName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Jumlah Tagihan:</span>
                  <span className="font-bold text-blue-700">{formatRupiah(adminPreviewProof.totalAmount)}</span>
                </div>
                {adminPreviewProof.transferNotes && (
                  <div className="flex justify-between text-slate-600 pt-1 border-t border-slate-200">
                    <span className="text-slate-500">Catatan Pengirim:</span>
                    <span className="italic">{adminPreviewProof.transferNotes}</span>
                  </div>
                )}
              </div>
            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between shrink-0">
              <button
                type="button"
                onClick={() => setAdminPreviewProof(null)}
                className="px-4 py-2 text-xs font-bold text-slate-600 hover:text-slate-900 border border-slate-300 rounded-xl"
              >
                Tutup
              </button>

              {adminPreviewProof.paymentStatus === 'pending_manual_verification' && (
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setAdminRejectOrder(adminPreviewProof);
                      setAdminPreviewProof(null);
                    }}
                    className="px-4 py-2 bg-red-50 hover:bg-red-100 text-red-700 font-bold text-xs rounded-xl border border-red-200 cursor-pointer"
                  >
                    Tolak Pembayaran
                  </button>
                  <button
                    type="button"
                    onClick={() => handleAdminApprove(adminPreviewProof)}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs cursor-pointer"
                  >
                    Setujui & Terbitkan Tiket
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* MODAL TOLAK PEMBAYARAN SUPER ADMIN */}
      {adminRejectOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-md w-full shadow-2xl border border-slate-200 p-6 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center gap-2 text-red-600">
              <XCircle className="w-5 h-5 shrink-0" />
              <h3 className="font-extrabold text-base text-slate-900">Tolak Pembayaran Manual</h3>
            </div>

            <p className="text-xs text-slate-600">
              Masukkan alasan penolakan untuk pesanan <strong>{adminRejectOrder.orderNumber}</strong>. Alasan ini akan tampil di dashboard pendaftar.
            </p>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Alasan Penolakan *</label>
              <textarea
                rows={3}
                required
                value={adminRejectReason}
                onChange={(e) => setAdminRejectReason(e.target.value)}
                placeholder="Contoh: Bukti transfer tidak valid atau dana belum masuk."
                className="w-full p-2.5 text-xs border border-slate-300 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-red-500"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setAdminRejectOrder(null)}
                className="px-4 py-2 text-xs font-bold text-slate-600 hover:text-slate-900 border border-slate-300 rounded-xl"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleAdminReject}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-xl shadow-xs"
              >
                Tolak Pembayaran
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
